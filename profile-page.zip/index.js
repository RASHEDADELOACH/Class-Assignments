//Create a function that will return a count of how many values are greater than x.
function countGreaterThanX(){
	var array = [-13, -15, -8, -29, -3, 4, 9, 10, -3, 7];
	var x = 14;
	var count = 0;
	//your code here
	return count; 
}


