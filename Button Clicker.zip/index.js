function likebutton1(){
	//console.log('testing');
	window.alert("Ninja was liked");

}
function likebutton2(){
	//console.log('testing2');	
	window.alert("Ninja was liked");
}
function definitionbutton(){
	document.getElementById("connection2-name").style.display = "none";
	
}

function loginbutton(){
	document.getElementById("sign-out-button").innerHTML = "Sign Out"
}




