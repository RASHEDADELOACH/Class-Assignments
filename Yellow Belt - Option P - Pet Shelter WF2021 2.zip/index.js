let pepperCountAdd = 4
let bruceCountAdd = 6
let oscarCountAdd = 9

function donateButton(){
	document.getElementById("sign-out-button").style.display = "none";
	
}
function searchButton(){
	var x = document.getElementById('search1-element').value;
	if (x=="cat") {
		window.alert("You are looking for a Cat");
	}
	if (x=="dog") {
		window.alert("You are looking for a Dog");
	}
}

function pepperButton(){
	//console.log('testing');
	document.getElementById("peppercount1").innerHTML = pepperCountAdd
	pepperCountAdd += 1; 
}
function bruceButton(){
	//console.log('testing');
	document.getElementById("brucecount1").innerHTML = bruceCountAdd
	bruceCountAdd += 1;
}
function oscarButton(){
	//console.log('testing');
	document.getElementById("oscarcount1").innerHTML = oscarCountAdd
	oscarCountAdd += 1;
}
