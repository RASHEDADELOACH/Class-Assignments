let likeCount1Add = 10
let likeCount2Add = 13
let likeCount3Add = 10

function likebutton1(){
	//console.log('testing');
	document.getElementById("likeCount1").innerHTML = likeCount1Add
	likeCount1Add += 1;

}
function likebutton2(){
	//console.log('testing2');	
	document.getElementById("likeCount2").innerHTML = likeCount2Add
	likeCount2Add += 1;
}
function likebutton3(){
	//console.log('testing2');	
	document.getElementById("likeCount3").innerHTML = likeCount3Add
	likeCount3Add += 1;
}
